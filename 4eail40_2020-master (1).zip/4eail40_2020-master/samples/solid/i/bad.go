package main

//Don't

type ItalianRestaurant interface {
	OrderPasta()
	OrderPizza()
	GetMenu()
}
